#!/system/bin/sh
# service.sh akan dieksekusi dalam keadaan "late_start" mode (sesudah sistem selesai boot)

MODDIR=${0%/*}
AWD_DIR="/data/adb/awd"
LOG_DIR="$AWD_DIR/tmp"
LOG_FILE="$LOG_DIR/awdos.log"

# Pastikan folder tmp dan config ada
mkdir -p "$LOG_DIR"
mkdir -p "$AWD_DIR/config"

# Mencegah duplikasi: Matikan semua instance service.sh dan anak-anaknya (watchdog lama)
for pid in $(pgrep -f "awd-os/service.sh"); do
    if [ "$pid" != "$$" ] && [ "$pid" != "$PPID" ]; then
        kill -9 "$pid" 2>/dev/null
    fi
done

# Deteksi jenis Root Manager dan simpan ke file
if [ -d "/data/adb/ksu" ] || [ -f "/data/adb/ksud" ]; then
    echo "KernelSU" > "$AWD_DIR/config/root_env.txt"
elif [ -d "/data/adb/magisk" ] || [ -f "/sbin/magisk" ]; then
    echo "Magisk" > "$AWD_DIR/config/root_env.txt"
else
    echo "Root" > "$AWD_DIR/config/root_env.txt"
fi

# Tunggu sampai boot selesai sepenuhnya
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 2
done

# Beri sedikit jeda agar tidak memberatkan saat awal hidup
sleep 5

# Fungsi untuk membatasi ukuran log (Log Rotator)
log_rotator() {
    while true; do
        sleep 900 # Cek setiap 15 menit
        if [ -f "$LOG_FILE" ]; then
            size=$(stat -c%s "$LOG_FILE" 2>/dev/null || echo 0)
            if [ "$size" -gt 524288 ]; then # Jika lebih dari 500KB
                tail -n 1000 "$LOG_FILE" > "$LOG_FILE.tmp"
                mv "$LOG_FILE.tmp" "$LOG_FILE"
            fi
        fi
    done
}
log_rotator &

# Fungsi Watchdog untuk menjaga AWD OS tetap hidup
start_watchdog() {
    while true; do
        if [ -f "$AWD_DIR/tmp/.disable_watchdog" ]; then
            sleep 5
            continue
        fi
        
        if [ -f "$AWD_DIR/awdos" ]; then
            cd "$AWD_DIR"
            chmod 755 awdos
            
            # Cek apakah awdos sudah berjalan normal agar tidak bentrok bind port 80
            if pidof awdos >/dev/null 2>&1; then
                sleep 5
                continue
            fi
            
            echo "=== [$(date)] Memulai layanan AWD OS WebUI... ===" >> "$LOG_FILE"
            # Jalankan server (blocking), log output ke awdos.log
            ./awdos -p 80 >> "$LOG_FILE" 2>&1
            echo "=== [$(date)] PERINGATAN: Layanan AWD OS terhenti/mati! Menyalakan ulang dalam 5 detik... ===" >> "$LOG_FILE"
        else
            echo "[$(date)] ERROR: Binary awdos tidak ditemukan! Mengecek ulang dalam 60 detik..." >> "$LOG_FILE"
            sleep 60
            continue
        fi
        sleep 5
    done
}

# Jalankan watchdog di background
start_watchdog &
echo "[$(date)] Watchdog AWD OS berhasil diluncurkan." >> "$LOG_FILE"
