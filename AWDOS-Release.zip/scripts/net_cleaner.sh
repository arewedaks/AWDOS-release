#!/system/bin/sh
# ============================================================================
# net_cleaner.sh — Pembersih darurat tunnel & netfilter ZenGoBox/AWD OS
# ----------------------------------------------------------------------------
# Tujuan: mencegah "internet terblokir" (blackhole) akibat rules iptables /
#         ip rule TPROXY yang tertinggal ketika sing-box/clash MATI.
#
# Skrip ini IDEMPOTEN: aman dijalankan berkali-kali kapan saja, bahkan saat
# tidak ada rules terpasang. Hanya menyentuh resource MILIK KITA saja
# (chain ZENNODE_* / CLASH_DNS_* dan fwmark 0x1000000 table 2024) sehingga
# TIDAK mengganggu rules bawaan Android (table ccmni1, dummy0, dsb).
#
# Dipakai oleh: magisk-module/service.sh (watchdog) sebelum restart awdos,
#               dan bisa dipanggil manual untuk pemulihan cepat.
# Lokasi saat terpasang: /data/adb/modules/awd-os/scripts/net_cleaner.sh
# ============================================================================

AWD_DIR="/data/adb/awd"
LOG_FILE="$AWD_DIR/tmp/awdos.log"
FW_MARK="16777216/16777216"   # 0x1000000, HARUS sama dengan netfilter/constants.go
TABLE_ID="2024"

log() {
    echo "[$(date)] [net_cleaner] $1" >> "$LOG_FILE" 2>/dev/null
    # Juga ke stdout agar terlihat bila dipanggil interaktif / dari terminal
    echo "[net_cleaner] $1"
}

# ---------------------------------------------------------------------------
# 1. Bersihkan chain custom di iptables/ip6tables (mangle & nat)
# ---------------------------------------------------------------------------
clean_chains() {
    ipt="$1"   # iptables | ip6tables

    # Format: <table>:<chain>
    for entry in \
        "mangle:ZENNODE_DIVERT" \
        "mangle:ZENNODE_EXTERNAL" \
        "mangle:ZENNODE_LOCAL" \
        "nat:ZENNODE_EXTERNAL" \
        "nat:ZENNODE_LOCAL" \
        "nat:CLASH_DNS_EXTERNAL" \
        "nat:CLASH_DNS_LOCAL"
    do
        tbl="${entry%%:*}"
        ch="${entry##*:}"

        # Hapus jump dari chain bawaan (bisa ada beberapa referensi)
        while $ipt -t "$tbl" -D PREROUTING -j "$ch" 2>/dev/null; do :; done
        while $ipt -t "$tbl" -D OUTPUT     -j "$ch" 2>/dev/null; do :; done

        # Kosongkan lalu hapus chain custom
        $ipt -t "$tbl" -F "$ch" 2>/dev/null
        $ipt -t "$tbl" -X "$ch" 2>/dev/null
    done
}

# ---------------------------------------------------------------------------
# 2. Bersihkan ip rule & route TPROXY (table 2024) untuk v4 & v6
# ---------------------------------------------------------------------------
clean_routing() {
    # Hapus SEMUA duplikat ip rule fwmark ... table 2024 (v4)
    while ip rule del fwmark "$FW_MARK" table "$TABLE_ID" 2>/dev/null; do :; done
    # v6
    while ip -6 rule del fwmark "$FW_MARK" table "$TABLE_ID" 2>/dev/null; do :; done

    # Flush route table 2024 agar tidak menyisakan default local dev lo
    ip route flush table "$TABLE_ID" 2>/dev/null
    ip -6 route flush table "$TABLE_ID" 2>/dev/null
}

# ---------------------------------------------------------------------------
# 3. Matikan sisa proses tunnel (sing-box / clash / mihomo)
# ---------------------------------------------------------------------------
clean_processes() {
    # Hanya nama binary yang memang dikelola AWD OS (lihat zengobox.yaml bin_list)
    for name in sing-box clash mihomo; do
        if pgrep -x "$name" >/dev/null 2>&1; then
            log "mematikan proses tunnel: $name (pids: $(pgrep -x "$name" | tr '\n' ' '))"
            killall "$name" 2>/dev/null
            sleep 1
            # Paksa jika masih hidup
            if pgrep -x "$name" >/dev/null 2>&1; then
                killall -9 "$name" 2>/dev/null
            fi
        fi
    done

    # Hapus file PID agar Status() tidak salah anggap masih berjalan
    rm -f "$AWD_DIR/zengobox/run/core.pid" 2>/dev/null
}

# ---------------------------------------------------------------------------
# 4. Hapus interface TUN sisa (jika mode tun / mixed pernah dipakai)
# ---------------------------------------------------------------------------
clean_tun() {
    for iface in tun0 utun tun awd-tun zengobox; do
        if ip link show "$iface" >/dev/null 2>&1; then
            log "menghapus interface tun sisa: $iface"
            ip link del "$iface" 2>/dev/null
        fi
    done
}

# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------
log "mulai pembersihan tunnel & netfilter..."

clean_chains iptables
clean_chains ip6tables
clean_routing
clean_processes
clean_tun

log "selesai: rules dibersihkan, traffic kembali ke jalur normal."

exit 0
