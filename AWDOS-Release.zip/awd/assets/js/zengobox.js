(function() {
    window.showToast = function(msg, type = 'success') {
        let container = document.querySelector('.zengo-toast-container');
        if (!container) {
            container = document.createElement('div');
            container.className = 'zengo-toast-container';
            container.style.cssText = 'position:fixed;bottom:20px;left:50%;transform:translateX(-50%);z-index:99999;display:flex;flex-direction:column;gap:10px;pointer-events:none;';
            document.body.appendChild(container);
        }
        const toast = document.createElement('div');
        const isError = type === 'error' || type === 'err' || type === 'danger';
        toast.style.cssText = `background: ${isError ? '#ff4d4f' : '#52c41a'}; color: white; padding: 10px 20px; border-radius: 8px; font-size: 13px; font-weight: bold; box-shadow: 0 4px 12px rgba(0,0,0,0.15); opacity: 0; transform: translateY(20px); transition: all 0.3s ease;`;
        toast.textContent = msg;
        container.appendChild(toast);
        setTimeout(() => { toast.style.opacity = '1'; toast.style.transform = 'translateY(0)'; }, 10);
        setTimeout(() => { 
            toast.style.opacity = '0'; toast.style.transform = 'translateY(20px)'; 
            setTimeout(() => { if (toast.parentNode) toast.remove(); }, 300);
        }, 3000);
    };
    const statusBadge = document.getElementById('status-badge');
    const statusText = document.getElementById('status-text');
    const powerSwitch = document.getElementById('power-switch');
    const coreSelector = document.getElementById('core-selector');
    const corePid = document.getElementById('core-pid');

    const terminal = document.getElementById('terminal');
    const btnScroll = document.getElementById('btn-scroll');

    let autoScroll = true;
    let isProcessing = false;
    let currentConfig = null;
    let forceShowSetup = false;

    // Settings Modal Elements
    const btnSettings = document.getElementById('btn-settings');
    const settingsModal = document.getElementById('settings-modal');
    const btnCloseSettings = document.getElementById('btn-close-settings');
    const btnSaveSettings = document.getElementById('btn-save-settings');


    // Toggle Auto Scroll
    btnScroll.addEventListener('click', () => {
        autoScroll = !autoScroll;
        btnScroll.classList.toggle('active', autoScroll);
        if (autoScroll) scrollToBottom();
    });

    terminal.addEventListener('scroll', () => {
        const isAtBottom = terminal.scrollHeight - terminal.scrollTop <= terminal.clientHeight + 10;
        if (!isAtBottom && autoScroll) {
            autoScroll = false;
            btnScroll.classList.remove('active');
        }
    });

    function scrollToBottom() {
        terminal.scrollTop = terminal.scrollHeight;
    }

    function formatLogLine(line) {
        if (!line) return '';
        
        // Strip ANSI color codes
        line = line.replace(/\x1B\[[0-9;]*[a-zA-Z]/g, '');
        
        let dateStr = '';
        let timeStr = '';
        let levelStr = '';
        let msgStr = line;
        
        // Match Clash format: time="2026-08-01T19:33:08..." level=info msg="..."
        const clashMatch = line.match(/time="(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2}:\d{2})[^"]*"\s+level=([^\s]+)\s+msg="([^"]*)"/);
        if (clashMatch) {
            dateStr = clashMatch[1].substring(2); // YY-MM-DD
            timeStr = clashMatch[2];
            levelStr = clashMatch[3].toLowerCase();
            msgStr = clashMatch[4];
        } else {
            // Match Sing-box format: +0700 2026-08-02 10:03:48 DEBUG [ID ms] message
            const sbMatch = line.match(/^(?:[+-]\d{4}\s+)?(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2}:\d{2})\s+([A-Z]+)\s+(.*)$/);
            if (sbMatch) {
                dateStr = sbMatch[1].substring(2); // YY-MM-DD
                timeStr = sbMatch[2];
                levelStr = sbMatch[3].toLowerCase();
                msgStr = sbMatch[4];
            } else {
                // Fallback parsing
                const timeExtract = line.match(/(?:^|\s|\[)(\d{2}:\d{2}:\d{2})(?:[\]\s.T]|$)/);
                if (timeExtract) timeStr = timeExtract[1];
                
                if (line.includes('INFO') || line.includes('info')) levelStr = 'info';
                else if (line.includes('WARN') || line.includes('warn')) levelStr = 'warn';
                else if (line.includes('ERROR') || line.includes('error')) levelStr = 'error';
                else if (line.includes('DEBUG') || line.includes('debug')) levelStr = 'debug';
                else if (line.includes('FATAL') || line.includes('fatal')) levelStr = 'fatal';
            }
        }
        
        let className = 'log-line';
        if (levelStr === 'info') className += ' log-info';
        else if (levelStr === 'warn') className += ' log-warn';
        else if (levelStr === 'error' || levelStr === 'fatal') className += ' log-error';
        
        let html = '';
        if (timeStr) {
            html += `<span class="log-time" style="color: var(--text-sub); margin-right: 8px;">[${timeStr}]</span>`;
        }
        
        if (levelStr) {
            let color = 'var(--text-main)';
            let displayLvl = levelStr.toUpperCase();
            if (levelStr === 'info') color = 'var(--success)';
            else if (levelStr === 'warn') color = 'var(--warning)';
            else if (levelStr === 'error' || levelStr === 'fatal') color = 'var(--error)';
            else if (levelStr === 'debug') color = 'var(--primary)';
            
            html += `<span style="color: ${color}; font-weight: 700; margin-right: 8px; min-width: 45px; display: inline-block;">${displayLvl}</span>`;
        }
        
        html += `<span class="log-msg" style="color: var(--text-main);">${msgStr}</span>`;
        
        return `<div class="${className}" style="margin-bottom: 3px; font-family: monospace; font-size: 11px;">${html}</div>`;
    }

    async function fetchLogs() {
        try {
            const res = await fetch('/api/zengobox/logs?t=' + Date.now(), { cache: 'no-store' });
            const resObj = await res.json();
            
            // Assuming data is lines of text
            const lines = resObj.logs || [];
            terminal.innerHTML = lines.map(formatLogLine).join('');
            if (autoScroll) scrollToBottom();
        } catch (e) {
            console.error('Failed to fetch logs', e);
        }
    }

    async function fetchStatus() {
        try {
            const res = await fetch('/api/zengobox/status?t=' + Date.now(), { cache: 'no-store' });
            const data = await res.json();
            
            if (data.needs_setup || forceShowSetup) {
                document.getElementById('setup-wizard').style.display = 'flex';
                document.getElementById('main-container').style.display = 'none';
                if (!data.needs_setup && forceShowSetup) {
                    document.getElementById('btn-cancel-setup').style.display = 'inline-block';
                } else {
                    document.getElementById('btn-cancel-setup').style.display = 'none';
                }
                return;
            } else {
                document.getElementById('setup-wizard').style.display = 'none';
                // Only force main-container to show if the settings page is not active
                const settingsPage = document.getElementById('settings-page');
                if (!settingsPage || settingsPage.style.display !== 'block') {
                    document.getElementById('main-container').style.display = 'block';
                }
            }
            
            // Update Status Badge
            statusBadge.className = `status-badge ${data.running ? 'active' : 'offline'}`;
            statusText.textContent = data.running ? 'Active' : 'Offline';
            
            // Update Core Info
            if (data.core) {
                if (coreSelector.value !== data.core) {
                    coreSelector.value = data.core;
                    if (typeof loadAccountsList === 'function') {
                        loadAccountsList();
                    }
                }
            }
            corePid.textContent = data.running && data.pid > 0 ? `PID: ${data.pid}` : 'PID: ---';
            
            // Update Switch (Only if not processing a click)
            if (!isProcessing) {
                powerSwitch.checked = data.running;
                powerSwitch.disabled = false;
            }
            
            // Auto-refresh accounts silently (flicker is prevented by dataset check)
            if (typeof loadAccountsList === 'function') {
                loadAccountsList();
            }
        } catch (e) {
            statusBadge.className = 'status-badge offline';
            statusText.textContent = 'Disconnected';
            powerSwitch.disabled = true;
        }
    }

    // Handle Switch Click
    powerSwitch.addEventListener('change', async (e) => {
        isProcessing = true;
        powerSwitch.disabled = true;
        
        const action = e.target.checked ? 'start' : 'stop';
        try {
            await fetch(`/api/zengobox/${action}`, { method: 'POST' });
            // Immediate fetch to reflect status
            await fetchStatus();
            await fetchLogs();
        } catch (err) {
            window.showToast('Failed to execute command: ' + err.message, 'error');
            e.target.checked = !e.target.checked; // Revert
        } finally {
            isProcessing = false;
            powerSwitch.disabled = false;
        }
    });

    // Handle Core Selector Change
    coreSelector.addEventListener('change', async (e) => {
        const newCore = e.target.value;
        const wasRunning = powerSwitch.checked;
        
        try {
            coreSelector.disabled = true;
            // Fetch current config
            const res = await fetch('/api/zengobox/config?t=' + Date.now(), { cache: 'no-store' });
            const cfg = await res.json();
            
            // Update and save
            cfg.Core.BinName = newCore;
            await fetch('/api/zengobox/config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(cfg)
            });
            
            // Restart if running
            if (wasRunning) {
                await fetch('/api/zengobox/stop', { method: 'POST' });
                await new Promise(r => setTimeout(r, 1000));
                await fetch('/api/zengobox/start', { method: 'POST' });
            }
            
            fetchStatus();
            loadAccountsList();
        } catch(err) {
            window.showToast('Failed to change core: ' + err.message, 'error');
        } finally {
            coreSelector.disabled = false;
        }
    });

    // Routing Engine & Acceleration Management
    window.loadEngineStatus = async function() {
        try {
            const res = await fetch('/api/network/engine/status?t=' + Date.now(), { cache: 'no-store' });
            if (!res.ok) return;
            const d = await res.json();

            const badge = document.getElementById('engine-tier-badge');
            const kVer = document.getElementById('kernel-version-text');
            const ebpfSup = document.getElementById('ebpf-support-text');
            const sel = document.getElementById('engine-mode-select');
            const quickBadge = document.getElementById('engine-quick-badge');

            if (kVer) kVer.innerText = (d.capabilities && d.capabilities.kernel_version) ? d.capabilities.kernel_version : '-';
            if (ebpfSup) {
                const hasBpf = d.capabilities && d.capabilities.bpf_supported;
                ebpfSup.innerText = hasBpf ? "Tersedia 🟢" : "Tidak Didukung ⚪";
                ebpfSup.style.color = hasBpf ? "var(--success)" : "var(--text-sub)";
            }
            if (sel && d.configured_mode) {
                sel.value = d.configured_mode;
            }

            const tier = d.active_tier || (d.capabilities && d.capabilities.best_tier) || 'redirect';
            if (badge) {
                if (tier === 'ebpf') {
                    badge.className = 'bdg st-on';
                    badge.innerText = '⚡ eBPF Active';
                } else if (tier === 'tproxy') {
                    badge.className = 'bdg st-on';
                    badge.innerText = '🛡️ TPROXY Active';
                } else {
                    badge.className = 'bdg st-warn';
                    badge.innerText = '🔄 REDIRECT Active';
                }
            }

            if (quickBadge) {
                quickBadge.style.display = 'inline-flex';
                if (tier === 'ebpf') {
                    quickBadge.className = 'bdg st-on';
                    quickBadge.innerText = '⚡ eBPF';
                } else if (tier === 'tproxy') {
                    quickBadge.className = 'bdg st-on';
                    quickBadge.innerText = '🛡️ TPROXY';
                } else {
                    quickBadge.className = 'bdg st-warn';
                    quickBadge.innerText = '🔄 REDIRECT';
                }
            }
        } catch (err) {
            console.log('Engine status load failed', err);
        }
    };

    window.changeEngineMode = async function(mode) {
        try {
            const res = await fetch('/api/network/engine/mode', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ mode: mode })
            });
            const d = await res.json();
            if (res.ok && d.status === 'success') {
                if (typeof window.showToast === 'function') {
                    window.showToast('✅ Mode Routing diubah: ' + mode.toUpperCase(), 'success');
                }
                window.loadEngineStatus();
            } else {
                if (typeof window.showToast === 'function') {
                    window.showToast('❌ Gagal mengubah mode: ' + (d.message || 'Error'), 'error');
                }
            }
        } catch (err) {
            if (typeof window.showToast === 'function') {
                window.showToast('❌ Gagal menghubungi server: ' + err.message, 'error');
            }
        }
    };

    // Polling intervals
    fetchStatus();
    fetchLogs();
    window.loadEngineStatus();
    setInterval(fetchStatus, 3000);
    setInterval(fetchLogs, 2000);

    // Settings Modal Logic
    async function openSettings() {
        try {
            window.loadEngineStatus();
            const res = await fetch('/api/zengobox/config?t=' + Date.now(), { cache: 'no-store' });
            currentConfig = await res.json();
            
            // Populate form
            document.getElementById('setting-core').value = currentConfig.Core.BinName || 'clash';
            document.getElementById('setting-network-mode').value = currentConfig.Network.Mode || 'tproxy';
            document.getElementById('setting-proxy-mode').value = currentConfig.Proxy.Mode || 'blacklist';
            document.getElementById('setting-ipv6').checked = currentConfig.Network.IPv6;
            document.getElementById('setting-dns').checked = currentConfig.Network.ClashDNSForward;
            document.getElementById('setting-quic').checked = currentConfig.Network.QUICBlock;
            document.getElementById('setting-memcg').checked = currentConfig.Cgroup.MemCG.Enabled;
            document.getElementById('setting-wifi').checked = currentConfig.Wifi.Enabled;
            document.getElementById('setting-cron').checked = currentConfig.Schedule.Enabled;
            document.getElementById('setting-rules').checked = currentConfig.Subscription.InjectRules;
            
            document.getElementById('main-container').style.display = 'none';
            document.getElementById('settings-page').style.display = 'block';
        } catch (e) {
            window.showToast('Failed to load settings: ' + e.message, 'error');
        }
    }

    function closeSettings() {
        document.getElementById('settings-page').style.display = 'none';
        document.getElementById('main-container').style.display = 'block';
    }

    async function saveSettings() {
        if (!currentConfig) return;
        
        btnSaveSettings.disabled = true;
        btnSaveSettings.textContent = 'Saving...';
        
        // Update config object
        currentConfig.Core.BinName = document.getElementById('setting-core').value;
        currentConfig.Network.Mode = document.getElementById('setting-network-mode').value;
        currentConfig.Proxy.Mode = document.getElementById('setting-proxy-mode').value;
        currentConfig.Network.IPv6 = document.getElementById('setting-ipv6').checked;
        currentConfig.Network.ClashDNSForward = document.getElementById('setting-dns').checked;
        currentConfig.Network.QUICBlock = document.getElementById('setting-quic').checked;
        currentConfig.Cgroup.MemCG.Enabled = document.getElementById('setting-memcg').checked;
        currentConfig.Wifi.Enabled = document.getElementById('setting-wifi').checked;
        currentConfig.Schedule.Enabled = document.getElementById('setting-cron').checked;
        currentConfig.Subscription.InjectRules = document.getElementById('setting-rules').checked;
        
        try {
            const res = await fetch('/api/zengobox/config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(currentConfig)
            });
            
            if (res.ok) {
                window.showToast('Settings saved! Restarting proxy service to apply changes...', 'success');
                await fetch('/api/zengobox/stop', { method: 'POST' });
                await new Promise(r => setTimeout(r, 1000));
                await fetch('/api/zengobox/start', { method: 'POST' });
                
                closeSettings();
                fetchStatus();
                loadAccountsList();
            } else {
                const errText = await res.text();
                window.showToast('Failed to save settings: ' + errText, 'error');
            }
        } catch (e) {
            window.showToast('Error saving settings: ' + e.message, 'error');
        } finally {
            btnSaveSettings.disabled = false;
            btnSaveSettings.textContent = 'Save Settings';
        }
    }

    btnSettings.addEventListener('click', openSettings);
    const btnCancelSettings = document.getElementById('btn-cancel-settings');
    if (btnCancelSettings) btnCancelSettings.addEventListener('click', closeSettings);
    btnSaveSettings.addEventListener('click', saveSettings);
    
    document.getElementById('setting-core').addEventListener('change', () => {
        loadAccountsList();
    });

    // Proxy Accounts (Box for Root Style) Logic
    const linkInput = document.getElementById('account-link-input');
    const btnSaveID = document.getElementById('btn-save-id');
    const btnSaveSG = document.getElementById('btn-save-sg');
    const listID = document.getElementById('account-list-id');
    const listSG = document.getElementById('account-list-sg');
    const proxyLoading = document.getElementById('proxy-loading-indicator');
    const btnEditAllID = document.getElementById('btn-edit-all-id');
    const btnEditAllSG = document.getElementById('btn-edit-all-sg');

    async function loadAccountsList() {
        if (!listID || !listSG) return;
        
        async function fetchAndRender(target, listElement, badgeId) {
            try {
                const core = coreSelector.value || 'sing-box';
                const res = await fetch('/api/zengobox/accounts?file=' + target + '&core=' + core + '&t=' + Date.now(), { cache: 'no-store' });
                const text = await res.text();
                
                // Prevent flicker if data hasn't changed
                if (listElement.dataset.lastText === text) return;
                listElement.dataset.lastText = text;
                
                let accounts = [];
                let isJson = false;
                let parsedJsonArr = [];
                let yamlBlocks = [];
                let originalParsed = null;
                
                // Extremely simple parsing
                const trimmed = text.trim();
                if (trimmed.startsWith('{') || trimmed.startsWith('[')) { // JSON (Sing-box)
                    isJson = true;
                    try {
                        const parsed = JSON.parse(text);
                        originalParsed = parsed;
                        const arr = Array.isArray(parsed) ? parsed : (parsed.outbounds || []);
                        parsedJsonArr = arr;
                        arr.forEach((obj, index) => {
                            accounts.push({ name: obj.tag || obj.name || 'Unknown', blockIdx: index });
                        });
                    } catch(e) {
                        alert('JSON Parse Error: ' + e.message + '\nText: ' + text.substring(0, 100));
                    }
                } else { // YAML (Clash)
                    // Keep all blocks so we don't lose headers
                    yamlBlocks = text.split(/(?=\n\s*-\s*name:|^-\s*name:)/);
                    yamlBlocks.forEach((b, index) => {
                        const match = b.match(/-\s*name:\s*(.+)/);
                        if (match) {
                            accounts.push({ name: match[1].trim(), blockIdx: index });
                        }
                    });
                }
                
                const badge = document.getElementById(badgeId);
                if (badge) {
                    badge.textContent = isJson ? 'JSON' : 'YAML';
                    badge.style.opacity = '1';
                    if (isJson) {
                        badge.style.color = '#3498db';
                        badge.style.background = 'rgba(52, 152, 219, 0.15)';
                    } else {
                        badge.style.color = '#e67e22';
                        badge.style.background = 'rgba(230, 126, 34, 0.15)';
                    }
                }
                
                listElement.innerHTML = '';
                if (accounts.length === 0) {
                    listElement.innerHTML = '<div style="font-size: 10px; text-align: center; font-style: italic; opacity: 0.5; margin-top: 15px; color: var(--text-sub);">Kosong</div>';
                    return;
                }
                
                accounts.forEach((accObj, idx) => {
                    const accName = accObj.name;
                    const blockIdx = accObj.blockIdx;
                    
                    const item = document.createElement('div');
                    item.style.cssText = 'display: flex; justify-content: space-between; align-items: center; background: rgba(0,0,0,0.1); border: 1px solid var(--border); border-radius: 8px; overflow: hidden; margin-bottom: 5px; min-width: 0;';
                    
                    const nameDiv = document.createElement('div');
                    nameDiv.style.cssText = 'padding: 8px 10px; font-size: 11px; font-weight: bold; flex-grow: 1; color: var(--text-main); cursor: pointer; display: flex; align-items: center; gap: 8px; min-width: 0;';
                    nameDiv.innerHTML = `<span class="material-symbols-outlined" style="font-size: 14px; opacity: 0.5; flex-shrink: 0;">edit_square</span> <span style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex-grow: 1;">${accName}</span>`;
                    
                    nameDiv.onclick = () => {
                        let rawContent = '';
                        if (isJson) {
                            rawContent = JSON.stringify(parsedJsonArr[blockIdx], null, 2);
                        } else {
                            rawContent = yamlBlocks[blockIdx].trim();
                        }
                        openEditModal(target, blockIdx, accName, rawContent, coreSelector.value || 'sing-box', isJson, originalParsed, yamlBlocks);
                    };
                    
                    const delBtn = document.createElement('button');
                    delBtn.style.cssText = `background: ${target === 'AKUN-ID' ? 'rgba(255,95,86,0.2)' : 'rgba(39,201,63,0.2)'}; color: ${target === 'AKUN-ID' ? '#FF5F56' : '#27C93F'}; border: none; padding: 8px 12px; cursor: pointer; display: flex; align-items: center; justify-content: center;`;
                    delBtn.innerHTML = '<span class="material-symbols-outlined" style="font-size: 14px;">delete</span>';
                    
                    delBtn.onclick = () => deleteAccount(target, blockIdx, accName, isJson, originalParsed, yamlBlocks);
                    
                    item.appendChild(nameDiv);
                    item.appendChild(delBtn);
                    listElement.appendChild(item);
                });
            } catch (e) {
                listElement.innerHTML = '<div style="font-size: 10px; text-align: center; color: red;">Error loading</div>';
            }
        }
        
        await fetchAndRender('AKUN-ID', listID, 'badge-id');
        await fetchAndRender('AKUN-SG', listSG, 'badge-sg');
    }
    
    function openEditModal(target, idx, name, rawContent, core, isJson, originalParsed, yamlBlocks) {
        const wrapper = document.createElement('div');
        wrapper.className = 'awd-modal-wrapper show active';
        wrapper.style.zIndex = '9999';
        
        const backdrop = document.createElement('div');
        backdrop.className = 'awd-modal-backdrop';
        backdrop.onclick = () => document.body.removeChild(wrapper);
        
        const modal = document.createElement('div');
        modal.className = 'awd-modal';
        modal.style.width = '95%';
        modal.style.maxWidth = '600px';
        modal.style.height = '95vh';
        modal.style.maxHeight = '95vh';
        modal.style.margin = '0';
        
        const header = document.createElement('div');
        header.className = 'awd-modal-header';
        const titleIcon = target === 'CORE-CONFIG' ? 'settings_suggest' : 'edit';
        const titlePrefix = target === 'CORE-CONFIG' ? 'Core Configuration:' : 'Edit Account:';
        header.innerHTML = `<div class="awd-modal-title flex items-center gap-2"><span class="material-symbols-outlined text-[18px]">${titleIcon}</span> ${titlePrefix} <span style="color:var(--primary);">${name}</span></div>`;
        
        const closeBtn = document.createElement('div');
        closeBtn.className = 'awd-modal-controls';
        closeBtn.onclick = () => document.body.removeChild(wrapper);
        header.appendChild(closeBtn);
        
        const body = document.createElement('div');
        body.className = 'awd-modal-body';
        body.style.padding = '20px';
        body.style.display = 'flex';
        body.style.flexDirection = 'column';
        body.style.flexGrow = '1';
        body.style.overflow = 'hidden';
        
        const textarea = document.createElement('textarea');
        textarea.style.cssText = 'width: 100%; flex-grow: 1; background: rgba(128,128,128,0.05); color: var(--text-main); border: 1px solid var(--border); border-radius: var(--inner-radius); padding: 12px; font-family: monospace; font-size: 0.75rem; resize: none; margin-bottom: 15px; outline: none;';
        textarea.value = rawContent;
        
        const footerBtns = document.createElement('div');
        footerBtns.style.cssText = 'display: flex; gap: 10px; width: 100%;';

        if (target === 'CORE-CONFIG') {
            const modalFileInput = document.createElement('input');
            modalFileInput.type = 'file';
            modalFileInput.accept = core === 'sing-box' ? '.json,application/json' : '.yaml,.yml,text/yaml,application/x-yaml';
            modalFileInput.style.display = 'none';
            modalFileInput.onchange = (e) => {
                const file = e.target.files[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = (evt) => {
                    textarea.value = evt.target.result;
                    window.showToast('File ' + file.name + ' berhasil dimuat ke editor', 'info');
                };
                reader.readAsText(file);
            };

            const uploadBtn = document.createElement('button');
            uploadBtn.type = 'button';
            uploadBtn.className = 'btn btn-s';
            uploadBtn.style.cssText = 'flex: 1; display: flex; align-items: center; justify-content: center; gap: 6px;';
            uploadBtn.innerHTML = '<span class="material-symbols-outlined text-[18px]">upload_file</span> Load File';
            uploadBtn.onclick = () => modalFileInput.click();
            footerBtns.appendChild(modalFileInput);
            footerBtns.appendChild(uploadBtn);
        }

        const saveBtn = document.createElement('button');
        saveBtn.className = 'btn btn-p';
        saveBtn.style.flex = '2';
        saveBtn.textContent = 'Save Changes';
        footerBtns.appendChild(saveBtn);
        
        saveBtn.onclick = async () => {
            saveBtn.disabled = true;
            saveBtn.textContent = 'Saving...';
            try {
                let finalContent = '';
                if (idx === -1) {
                    // Edit All mode: rawContent is the entire file
                    finalContent = textarea.value;
                } else {
                    // Single block edit mode
                    if (isJson) {
                        const updatedObj = JSON.parse(textarea.value);
                        const arr = Array.isArray(originalParsed) ? originalParsed : originalParsed.outbounds;
                        arr[idx] = updatedObj;
                        finalContent = JSON.stringify(originalParsed, null, 2);
                    } else {
                        yamlBlocks[idx] = '\n' + textarea.value.trim() + '\n';
                        finalContent = yamlBlocks.join('');
                    }
                }
                
                let endpoint = '/api/zengobox/accounts?file=' + target + '&core=' + core;
                if (target === 'CORE-CONFIG') {
                    endpoint = '/api/zengobox/core-config?core=' + core;
                }
                
                const res = await fetch(endpoint, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ content: finalContent })
                });
                
                if (res.ok) {
                    window.showToast('Berhasil disimpan!', 'success');
                    document.body.removeChild(wrapper);
                    if (target !== 'CORE-CONFIG') {
                        loadAccountsList();
                    } else {
                        window.showToast('Proxy otomatis me-restart...', 'info');
                        await fetch('/api/zengobox/restart', { method: 'POST' });
                        fetchStatus();
                    }
                    if (target === 'AKUN-ID') listID.dataset.lastText = '';
                    if (target === 'AKUN-SG') listSG.dataset.lastText = '';
                    loadAccountsList();
                } else {
                    const errText = await res.text();
                    window.showToast('Save failed: ' + errText, 'error');
                }
            } catch(e) {
                window.showToast('Invalid format: ' + e.message, 'error');
            }
            saveBtn.disabled = false;
            saveBtn.textContent = 'Save Changes';
        };
        
        body.appendChild(textarea);
        body.appendChild(footerBtns);
        modal.appendChild(header);
        modal.appendChild(body);
        wrapper.appendChild(backdrop);
        wrapper.appendChild(modal);
        document.body.appendChild(wrapper);
    }

    async function deleteAccount(target, idx, name, isJson, originalParsed, yamlBlocks) {
        if (!confirm('Hapus akun: ' + name + '?')) return;
        proxyLoading.style.display = 'block';
        const core = coreSelector.value || 'sing-box';
        
        try {
            let finalContent = '';
            if (isJson) {
                const arr = Array.isArray(originalParsed) ? originalParsed : originalParsed.outbounds;
                arr.splice(idx, 1);
                finalContent = JSON.stringify(originalParsed, null, 2);
            } else {
                yamlBlocks.splice(idx, 1);
                finalContent = yamlBlocks.join('');
            }
            
            await fetch('/api/zengobox/accounts?file=' + target + '&core=' + core, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ content: finalContent })
            });
            
            window.showToast('Akun dihapus', 'success');
            if (target === 'AKUN-ID') listID.dataset.lastText = '';
            if (target === 'AKUN-SG') listSG.dataset.lastText = '';
            loadAccountsList();
        } catch (e) {
            window.showToast('Gagal menghapus: ' + e.message, 'error');
        } finally {
            proxyLoading.style.display = 'none';
        }
    }

    async function processAndSave(target) {
        const link = linkInput.value.trim();
        if (!link) {
            window.showToast('Masukkan link terlebih dahulu!', 'warning');
            return;
        }
        
        proxyLoading.style.display = 'block';
        const core = coreSelector.value || 'sing-box';
        try {
            // Convert Link
            const convertRes = await fetch('/api/zengobox/accounts/convert?core=' + core, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ link })
            });
            
            if (!convertRes.ok) throw new Error(await convertRes.text());
            const parsedObj = await convertRes.json();
            
            // Get Current File
            const res = await fetch('/api/zengobox/accounts?file=' + target + '&core=' + core + '&t=' + Date.now(), { cache: 'no-store' });
            let text = await res.text();
            
            if (parsedObj.yaml) { // YAML returned (Clash)
                if (!text.includes('proxies:')) {
                    text = 'proxies:\n' + text;
                }
                text = text.trim() + '\n' + parsedObj.yaml;
            } else { // JSON returned (Singbox)
                const trimmed = text.trim();
                let parsed = { outbounds: [] };
                let arr = [];
                if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
                    try { 
                        parsed = JSON.parse(text); 
                        arr = Array.isArray(parsed) ? parsed : (parsed.outbounds || []);
                    } catch(e) {
                        alert('JSON Parse Error in Save: ' + e.message);
                    }
                }
                arr.push(parsedObj);
                if (!Array.isArray(parsed)) {
                    parsed.outbounds = arr;
                } else {
                    parsed = arr;
                }
                text = JSON.stringify(parsed, null, 2);
            }
            
            const saveRes = await fetch('/api/zengobox/accounts?file=' + target + '&core=' + core, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ content: text })
            });
            if (!saveRes.ok) throw new Error(await saveRes.text());

            
            window.showToast('Berhasil disimpan ke ' + target, 'success');
            linkInput.value = '';
            loadAccountsList();
        } catch (e) {
            window.showToast('Gagal memproses: ' + e.message, 'error');
        } finally {
            proxyLoading.style.display = 'none';
        }
    }

    if (btnSaveID) btnSaveID.addEventListener('click', () => processAndSave('AKUN-ID'));
    if (btnSaveSG) btnSaveSG.addEventListener('click', () => processAndSave('AKUN-SG'));
    
    async function openEditAll(target) {
        const core = coreSelector.value || 'sing-box';
        proxyLoading.style.display = 'block';
        try {
            const res = await fetch('/api/zengobox/accounts?file=' + target + '&core=' + core + '&t=' + Date.now(), { cache: 'no-store' });
            const text = await res.text();
            openEditModal(target, -1, 'ALL ACCOUNTS (' + target + ')', text, core, false, null, null);
        } catch (e) {
            window.showToast('Gagal memuat file: ' + e.message, 'error');
        }
        proxyLoading.style.display = 'none';
    }

    if (btnEditAllID) {
        btnEditAllID.addEventListener('click', () => openEditAll('AKUN-ID'));
    }
    
    if (btnEditAllSG) {
        btnEditAllSG.addEventListener('click', () => openEditAll('AKUN-SG'));
    }

    // Initial load of account lists
    loadAccountsList();


    // Close modal on outside click
    if (settingsModal) {
        settingsModal.addEventListener('click', (e) => {
            if (e.target === settingsModal) {
                settingsModal.classList.remove('show');
            }
        });
    }

    // Wizard Logic
    const btnStartSetup = document.getElementById('btn-start-setup');
    const btnCancelSetup = document.getElementById('btn-cancel-setup');
    const btnShowSetup = document.getElementById('btn-show-setup');
    const logsPanel = document.getElementById('setup-logs-panel');
    const setupTerminal = document.getElementById('setup-terminal');
    const setupStatusText = document.getElementById('setup-status-text');

    if (btnShowSetup) {
        btnShowSetup.addEventListener('click', () => {
            forceShowSetup = true;
            fetchStatus();
        });
    }

    if (btnCancelSetup) {
        btnCancelSetup.addEventListener('click', () => {
            forceShowSetup = false;
            fetchStatus();
        });
    }

    window.openCoreConfigModal = async function() {
        const core = coreSelector.value || 'sing-box';
        proxyLoading.style.display = 'block';
        try {
            const res = await fetch('/api/zengobox/core-config?core=' + core + '&t=' + Date.now(), { cache: 'no-store' });
            if (!res.ok) throw new Error('HTTP ' + res.status);
            const text = await res.text();
            const fileName = core === 'sing-box' ? 'config.json' : 'config.yaml';
            openEditModal('CORE-CONFIG', -1, 'CORE CONFIG (' + fileName + ')', text, core, false, null, null);
        } catch (e) {
            window.showToast('Gagal memuat core config: ' + e.message, 'error');
        }
        proxyLoading.style.display = 'none';
    };

    window.triggerCoreConfigUpload = function() {
        const fileInput = document.getElementById('core-config-file-input');
        if (!fileInput) return;
        const core = coreSelector.value || 'sing-box';
        fileInput.accept = core === 'sing-box' ? '.json,application/json' : '.yaml,.yml,text/yaml,application/x-yaml';
        fileInput.value = '';
        fileInput.click();
    };

    window.handleCoreConfigFileSelected = async function(event) {
        const file = event.target.files && event.target.files[0];
        if (!file) return;

        const core = coreSelector.value || 'sing-box';
        const ext = file.name.split('.').pop().toLowerCase();
        
        if (core === 'sing-box' && ext !== 'json') {
            window.showToast('Core Sing-Box hanya menerima file berekstensi .json!', 'error');
            return;
        }
        if (core === 'clash' && ext !== 'yaml' && ext !== 'yml') {
            window.showToast('Core Clash hanya menerima file berekstensi .yaml atau .yml!', 'error');
            return;
        }

        proxyLoading.style.display = 'block';
        const reader = new FileReader();
        reader.onload = async function(e) {
            const content = e.target.result;
            try {
                // Client-side quick syntax check for JSON
                if (core === 'sing-box') {
                    JSON.parse(content);
                }
                
                const res = await fetch('/api/zengobox/core-config?core=' + core, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ content: content })
                });

                if (res.ok) {
                    window.showToast(`Berhasil mengunggah ${file.name} untuk ${core}!`, 'success');
                    window.showToast('Proxy otomatis me-restart...', 'info');
                    await fetch('/api/zengobox/restart', { method: 'POST' });
                    fetchStatus();
                } else {
                    const errText = await res.text();
                    window.showToast('Gagal upload: ' + errText, 'error');
                }
            } catch (err) {
                window.showToast('Format file tidak valid: ' + err.message, 'error');
            } finally {
                proxyLoading.style.display = 'none';
            }
        };
        reader.onerror = function() {
            window.showToast('Gagal membaca file lokal!', 'error');
            proxyLoading.style.display = 'none';
        };
        reader.readAsText(file);
    };

    function startPolling() {
        const pollInterval = setInterval(async () => {
            try {
                const res = await fetch('/api/zengobox/setup_log');
                const text = await res.text();
                if (text && text.trim() !== "" && text !== "Waiting for logs...") {
                    setupTerminal.innerText = text;
                    setupTerminal.scrollTop = setupTerminal.scrollHeight;
                }
                
                if (text.includes("Setup complete!")) {
                    clearInterval(pollInterval);
                    setupStatusText.innerText = "Setup complete! Restarting daemon...";
                    setupStatusText.style.color = "#10b981";
                    
                    // Restart daemon so it loads the new config and drops Setup Mode
                    await fetch('/api/zengobox/restart', { method: 'POST' });
                    
                    setTimeout(() => {
                        window.location.reload();
                    }, 3000);
                } else if (text.includes("[SETUP_FAILED]")) {
                    clearInterval(pollInterval);
                    setupStatusText.innerText = "Setup failed. Check the logs above.";
                    setupStatusText.style.color = "#ef4444"; // Red color
                    btnStartSetup.disabled = false;
                    btnStartSetup.innerHTML = 'Retry Installation';
                }
            } catch (e) {
                console.error(e);
            }
        }, 1000);
    }

    if (btnStartSetup) {
        btnStartSetup.addEventListener('click', async () => {
            const core = document.getElementById('setup-core').value;
            const mirror = document.getElementById('setup-mirror').value;
            const dashboard = document.getElementById('setup-dashboard').value;

            btnStartSetup.disabled = true;
            btnStartSetup.innerHTML = 'Installing...';
            logsPanel.style.display = 'block';
            setupTerminal.innerText = "> Preparing environment...\n";

            try {
                await fetch('/api/zengobox/setup', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ core: core, mirror: mirror, dashboard: dashboard })
                });

                startPolling();
            } catch (e) {
                window.showToast('Setup failed: ' + e.message, 'error');
                btnStartSetup.disabled = false;
                btnStartSetup.innerHTML = '🚀 Start Installation';
            }
        });

        // Auto-resume checking
        const checkExistingSetup = async () => {
            try {
                const res = await fetch('/api/zengobox/setup_log');
                const text = await res.text();
                // If there's a log, and it hasn't failed, and hasn't completed, and isn't just waiting
                if (text && text.trim() !== "" && text !== "Waiting for logs..." && !text.includes("[SETUP_FAILED]") && !text.includes("Setup complete!")) {
                    btnStartSetup.disabled = true;
                    btnStartSetup.innerHTML = 'Installing... (Resumed)';
                    logsPanel.style.display = 'block';
                    setupTerminal.innerText = text;
                    setupTerminal.scrollTop = setupTerminal.scrollHeight;
                    
                    // Resume polling without triggering a new setup
                    startPolling();
                }
            } catch (e) {}
        };
        setTimeout(checkExistingSetup, 500);
    }
})();
