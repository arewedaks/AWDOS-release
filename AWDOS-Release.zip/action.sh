#!/system/bin/sh
# ============================================================================
# action.sh — Tombol aksi (Action Button) modul AWD OS
# ----------------------------------------------------------------------------
# Dipanggil oleh Magisk / KernelSU saat pengguna menekan tombol "Action".
# Berfungsi sebagai TOGGLE untuk mematikan / menghidupkan layanan awdos.
#
# Cara kerja:
#   - Flag "$MODDIR/.awdos_off" menyimpan status OFF (awdos dimatikan).
#     Selama flag ada, watchdog (service.sh) TIDAK akan menghidupkan awdos.
#   - Toggle ON  : hapus flag, lalu nyalakan awdos (detached).
#   - Toggle OFF : buat flag, bersihkan tunnel & netfilter (net_cleaner.sh),
#                  lalu hentikan proses awdos.
#
# Saat terpasang, MODDIR = /data/adb/modules/awd-os
# ============================================================================

MODDIR=${0%/*}
AWD_DIR="/data/adb/awd"
LOG_FILE="$AWD_DIR/tmp/awdos.log"
FLAG_OFF="$MODDIR/.awdos_off"
MODPROP="$MODDIR/module.prop"

log() {
    echo "[$(date)] [action] $1" >> "$LOG_FILE" 2>/dev/null
}

# Tampilkan pesan ke user (KernelSU: ui_print; fallback: toast/log)
say() {
    echo "$1"
    if command -v ui_print >/dev/null 2>&1; then
        ui_print "$1"
    fi
    # Toast bila tersedia (beberapa root manager)
    if command -v toast >/dev/null 2>&1; then
        toast "$1" 2>/dev/null
    fi
}

# Perbarui deskripsi modul agar status terlihat di aplikasi root manager
set_description() {
    [ -f "$MODPROP" ] || return 0
    # Ambil deskripsi dasar (tanpa prefix status lama)
    base="Mengubah ponsel Android menjadi Router & Server yang tangguh. Dilengkapi WebUI untuk File Manager, kontrol jaringan, dan System Tools."
    case "$1" in
        off) newdesc="⏸ AWD OS OFFLINE (WebUI dimatikan via Action). $base" ;;
        on)  newdesc="⚡ AWD OS ONLINE. $base" ;;
        *)   newdesc="$base" ;;
    esac
    # Hapus baris description lama, tulis ulang
    grep -v '^description=' "$MODPROP" > "$MODPROP.tmp" 2>/dev/null
    echo "description=$newdesc" >> "$MODPROP.tmp"
    mv -f "$MODPROP.tmp" "$MODPROP"
}

mkdir -p "$AWD_DIR/tmp"

# ---------------------------------------------------------------------------
# Tentukan aksi berdasarkan keberadaan flag
# ---------------------------------------------------------------------------
if [ -f "$FLAG_OFF" ]; then
    # -------- Saat ini OFF -> HIDUPKAN --------
    say "Menghidupkan AWD OS..."

    # Hapus flag agar watchdog kembali menjaga awdos
    rm -f "$FLAG_OFF"

    # Pastikan folder tmp & config ada
    mkdir -p "$AWD_DIR/tmp" "$AWD_DIR/config"

    # Jalankan awdos (detached). Watchdog juga akan menjaganya.
    if [ -f "$AWD_DIR/awdos" ]; then
        chmod 755 "$AWD_DIR/awdos"
        cd "$AWD_DIR" || exit 1
        # nohup + & agar tidak memblokir action.sh; output tetap ke log
        nohup ./awdos -p 80 >> "$LOG_FILE" 2>&1 &
        log "awdos dihidupkan via action.sh"
        say "✅ AWD OS DIHIDUPKAN. WebUI: http://127.0.0.1"
        set_description on
    else
        say "❌ Binary awdos tidak ditemukan!"
        log "GAGAL: binary awdos tidak ditemukan"
    fi
else
    # -------- Saat ini ON -> MATIKAN --------
    say "Mematikan AWD OS..."

    # Buat flag agar watchdog TIDAK menghidupkan ulang
    touch "$FLAG_OFF"

    # Bersihkan tunnel & netfilter dulu supaya internet tidak terblokir
    if [ -f "$MODDIR/scripts/net_cleaner.sh" ]; then
        sh "$MODDIR/scripts/net_cleaner.sh"
    else
        log "WARNING: net_cleaner.sh tidak ditemukan, lewati pembersihan"
    fi

    # Hentikan proses awdos
    pidof awdos >/dev/null 2>&1 && killall awdos 2>/dev/null
    sleep 1
    pidof awdos >/dev/null 2>&1 && killall -9 awdos 2>/dev/null

    log "awdos dimatikan via action.sh"
    say "⏸ AWD OS DIMATIKAN. Tunnel & netfilter dibersihkan."
    set_description off
fi

exit 0
