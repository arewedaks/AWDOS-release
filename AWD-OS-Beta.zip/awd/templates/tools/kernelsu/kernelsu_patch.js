        function showProfileTab() {
            document.getElementById('module-section').style.display = 'none';
            document.getElementById('log-section').style.display = 'none';
            document.getElementById('install-section').style.display = 'none';
            document.getElementById('profile-section').style.display = 'block';
            loadSUProfiles();
        }

        function loadSUProfiles() {
            const list = document.getElementById('profile-list');
            list.innerHTML = '<div class="text-center py-8 text-[var(--text-sub)]">Memuat daftar aplikasi...</div>';
            
            fetch('/api/kernelsu/profiles')
            .then(r => r.json())
            .then(apps => {
                if(!apps || apps.length === 0) {
                    list.innerHTML = '<div class="text-center py-8 text-[var(--text-sub)]">Tidak ada aplikasi pihak ketiga ditemukan.</div>';
                    return;
                }
                
                // Sort apps: Granted first, then by name
                apps.sort((a, b) => {
                    if (a.rootGranted && !b.rootGranted) return -1;
                    if (!a.rootGranted && b.rootGranted) return 1;
                    return a.appName.localeCompare(b.appName);
                });
                
                let html = '';
                apps.forEach(app => {
                    html += `
                    <div class="bg-[var(--card-bg)] border border-[var(--border)] rounded-xl p-4 flex items-center justify-between gap-3 hover:border-blue-500/30 transition-colors">
                        <div class="flex-1 min-w-0">
                            <h3 class="font-bold text-sm truncate">${app.appName}</h3>
                            <div class="text-[11px] font-mono text-[var(--text-sub)] mt-0.5 truncate">UID: ${app.uid}</div>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" class="sr-only peer" ${app.rootGranted ? 'checked' : ''} 
                                onchange="toggleProfile('${app.packageName}', '${app.uid}', this.checked)">
                            <div class="w-11 h-6 bg-[var(--surface)] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500 border border-[var(--border)]"></div>
                        </label>
                    </div>`;
                });
                list.innerHTML = html;
            })
            .catch(e => {
                list.innerHTML = `<div class="text-center py-8 text-red-500">Gagal memuat: ${e}</div>`;
            });
        }

        function toggleProfile(pkg, uid, grant) {
            fetch('/api/kernelsu/profiles/toggle', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `package=${encodeURIComponent(pkg)}&uid=${encodeURIComponent(uid)}&grant=${grant}`
            })
            .then(r => r.json())
            .then(res => {
                if(res.status === 'success') {
                    showToast('Izin root diperbarui. Silakan reboot jika diperlukan.');
                } else {
                    showToast('Gagal: ' + res.message, true);
                    loadSUProfiles(); // Revert toggle visually
                }
            })
            .catch(e => {
                showToast('Error: ' + e.toString(), true);
                loadSUProfiles();
            });
        }
