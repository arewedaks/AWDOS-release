#!/system/bin/sh
# Script untuk Update AWD OS via CURL dari GitHub
# File ini diletakkan di /data/adb/awd/update_awd.sh

AWD_DIR="/data/adb/awd"
# Ganti URL ini dengan URL raw/release file zip update Anda di GitHub
# Contoh: https://raw.githubusercontent.com/arewedaks/AWDOS-release/main/AWD-OS-Beta.zip
UPDATE_URL="https://raw.githubusercontent.com/arewedaks/AWDOS-release/main/AWD-OS-Beta.zip"
TMP_ZIP="/data/local/tmp/awd_update.zip"
TMP_DIR="/data/local/tmp/awd_update_extracted"

echo "Memeriksa pembaruan AWD OS..."

# Download file zip menggunakan curl (Tambahkan timestamp untuk memotong cache GitHub)
curl -sL -o "$TMP_ZIP" "$UPDATE_URL?t=$(date +%s)"

if [ $? -ne 0 ]; then
    echo "Gagal mengunduh pembaruan. Periksa koneksi internet Anda."
    exit 1
fi

echo "Pembaruan berhasil diunduh. Memproses instalasi..."

# Bersihkan folder temp ekstraksi lama jika ada
rm -rf "$TMP_DIR"
mkdir -p "$TMP_DIR"

# Ekstrak zip Magisk yang baru diunduh
unzip -q -o "$TMP_ZIP" -d "$TMP_DIR"

if [ -d "$TMP_DIR/awd" ]; then
    echo "Menghentikan layanan AWD OS sementara..."
    # Tahan watchdog agar tidak otomatis menyalakan ulang
    touch "$AWD_DIR/tmp/.disable_watchdog"
    killall -9 awdos 2>/dev/null
    killall -9 zengobox 2>/dev/null
    
    echo "Menyalin file baru..."
    # Hapus folder lama agar tidak ada file sisa/usang, dan hapus binary lama
    rm -rf "$AWD_DIR/assets" "$AWD_DIR/templates" "$AWD_DIR/libs" "$AWD_DIR/zengobox/webroot"
    rm -f "$AWD_DIR/zengobox/zengobox"
    
    # Salin file baru ke direktori /data/adb/awd
    cp -rf "$TMP_DIR/awd/"* "$AWD_DIR/"
    chmod 755 "$AWD_DIR/awdos"
    chmod 755 "$AWD_DIR/zengobox/zengobox"
    
    # Perbarui file-file sistem Magisk/KernelSU di luar folder awd/ agar terbaca versi terbaru & logika service terbaru
    if [ -d "/data/adb/modules/awd-os" ]; then
        cp -f "$TMP_DIR/module.prop" "/data/adb/modules/awd-os/module.prop"
        cp -f "$TMP_DIR/service.sh" "/data/adb/modules/awd-os/service.sh"
        cp -f "$TMP_DIR/uninstall.sh" "/data/adb/modules/awd-os/uninstall.sh"
        chmod 755 "/data/adb/modules/awd-os/service.sh" "/data/adb/modules/awd-os/uninstall.sh"
    fi
    
    echo "Pembaruan berhasil disalin. Melepas watchdog..."
    rm -f "$AWD_DIR/tmp/.disable_watchdog"
    
    echo "Menyalakan ulang layanan AWD OS..."
    cd "$AWD_DIR"
    mkdir -p "$AWD_DIR/tmp"
    mkdir -p "$AWD_DIR/config"
    if [ -d "/data/adb/ksu" ] || [ -f "/data/adb/ksud" ]; then
        echo "KernelSU" > "$AWD_DIR/config/root_env.txt"
    elif [ -d "/data/adb/magisk" ] || [ -f "/sbin/magisk" ]; then
        echo "Magisk" > "$AWD_DIR/config/root_env.txt"
    else
        echo "Root" > "$AWD_DIR/config/root_env.txt"
    fi
    
    # Watchdog akan secara otomatis mendeteksi dan menjalankan ulang awdos
    echo "Pembaruan selesai! Watchdog akan menjalankan ulang layanan dalam beberapa detik."
else
    echo "Gagal: Format file pembaruan tidak dikenali."
fi

# Pembersihan
rm -f "$TMP_ZIP"
rm -rf "$TMP_DIR"
