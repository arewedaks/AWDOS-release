document.addEventListener('DOMContentLoaded', () => {
    const statusBadge = document.getElementById('status-badge');
    const statusText = document.getElementById('status-text');
    const powerSwitch = document.getElementById('power-switch');
    const coreSelector = document.getElementById('core-selector');
    const corePid = document.getElementById('core-pid');
    const btnClash = document.getElementById('btn-clash');
    const terminal = document.getElementById('terminal');
    const btnScroll = document.getElementById('btn-scroll');

    let autoScroll = true;
    let isProcessing = false;
    let currentConfig = null;
    let forceShowSetup = false;

    // Settings Modal Elements
    const btnSettings = document.getElementById('btn-settings');
    const settingsModal = document.getElementById('settings-modal');
    const btnCloseSettings = document.getElementById('btn-close-settings');
    const btnSaveSettings = document.getElementById('btn-save-settings');

    // Toggle Auto Scroll
    btnScroll.addEventListener('click', () => {
        autoScroll = !autoScroll;
        btnScroll.classList.toggle('active', autoScroll);
        if (autoScroll) scrollToBottom();
    });

    terminal.addEventListener('scroll', () => {
        const isAtBottom = terminal.scrollHeight - terminal.scrollTop <= terminal.clientHeight + 10;
        if (!isAtBottom && autoScroll) {
            autoScroll = false;
            btnScroll.classList.remove('active');
        }
    });

    function scrollToBottom() {
        terminal.scrollTop = terminal.scrollHeight;
    }

    function formatLogLine(line) {
        if (!line) return '';
        let className = 'log-line';
        if (line.includes('[INFO]')) className += ' log-info';
        else if (line.includes('[WARN]')) className += ' log-warn';
        else if (line.includes('[ERROR]') || line.includes('[FATAL]')) className += ' log-error';

        // Extract time if exists (assuming HH:MM:SS format at start)
        const timeMatch = line.match(/^(\d{2}:\d{2}:\d{2})/);
        if (timeMatch) {
            line = line.replace(timeMatch[0], `<span class="log-time">${timeMatch[0]}</span>`);
        }
        
        return `<div class="${className}">${line}</div>`;
    }

    async function fetchLogs() {
        try {
            const res = await fetch('/api/logs');
            const data = await res.json();
            
            if (data.logs && data.logs.length > 0) {
                terminal.innerHTML = data.logs.map(formatLogLine).join('');
                if (autoScroll) scrollToBottom();
            }
        } catch (e) {
            console.error('Failed to fetch logs', e);
        }
    }

    async function fetchStatus() {
        try {
            const res = await fetch('/api/status');
            const data = await res.json();
            
            if (data.needs_setup || forceShowSetup) {
                document.getElementById('setup-wizard').style.display = 'block';
                document.getElementById('main-container').style.display = 'none';
                if (!data.needs_setup && forceShowSetup) {
                    document.getElementById('btn-cancel-setup').style.display = 'inline-block';
                } else {
                    document.getElementById('btn-cancel-setup').style.display = 'none';
                }
                return;
            } else {
                document.getElementById('setup-wizard').style.display = 'none';
                document.getElementById('main-container').style.display = 'block';
            }
            
            // Update Status Badge
            statusBadge.className = `status-badge ${data.running ? 'active' : 'offline'}`;
            statusText.textContent = data.running ? 'Active' : 'Offline';
            
            // Update Core Info
            if (data.core) {
                coreSelector.value = data.core;
            }
            corePid.textContent = data.running && data.pid > 0 ? `PID: ${data.pid}` : 'PID: ---';
            
            // Clash/Sing-box Dashboard Button
            btnClash.style.display = ((data.core === 'clash' || data.core === 'sing-box') && data.running) ? 'inline-block' : 'none';

            // Update Switch (Only if not processing a click)
            if (!isProcessing) {
                powerSwitch.checked = data.running;
                powerSwitch.disabled = false;
            }
        } catch (e) {
            statusBadge.className = 'status-badge offline';
            statusText.textContent = 'Disconnected';
            powerSwitch.disabled = true;
        }
    }

    // Handle Switch Click
    powerSwitch.addEventListener('change', async (e) => {
        isProcessing = true;
        powerSwitch.disabled = true;
        
        const action = e.target.checked ? 'start' : 'stop';
        try {
            await fetch(`/api/${action}`, { method: 'POST' });
            // Immediate fetch to reflect status
            await fetchStatus();
            await fetchLogs();
        } catch (err) {
            alert('Failed to execute command: ' + err.message);
            e.target.checked = !e.target.checked; // Revert
        } finally {
            isProcessing = false;
            powerSwitch.disabled = false;
        }
    });

    // Handle Core Selector Change
    coreSelector.addEventListener('change', async (e) => {
        const newCore = e.target.value;
        const wasRunning = powerSwitch.checked;
        
        try {
            coreSelector.disabled = true;
            // Fetch current config
            const res = await fetch('/api/config');
            const cfg = await res.json();
            
            // Update and save
            cfg.Core.BinName = newCore;
            await fetch('/api/config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(cfg)
            });
            
            // Restart if running
            if (wasRunning) {
                await fetch('/api/stop', { method: 'POST' });
                await new Promise(r => setTimeout(r, 1000));
                await fetch('/api/start', { method: 'POST' });
            }
            
            fetchStatus();
        } catch(err) {
            alert('Failed to change core: ' + err.message);
        } finally {
            coreSelector.disabled = false;
        }
    });

    // Polling intervals
    fetchStatus();
    fetchLogs();
    setInterval(fetchStatus, 3000);
    setInterval(fetchLogs, 2000);

    // Settings Modal Logic
    async function openSettings() {
        try {
            const res = await fetch('/api/config');
            currentConfig = await res.json();
            
            // Populate form
            document.getElementById('setting-core').value = currentConfig.Core.BinName || 'clash';
            document.getElementById('setting-wifi').checked = currentConfig.Wifi.Enabled;
            document.getElementById('setting-cron').checked = currentConfig.Schedule.Enabled;
            document.getElementById('setting-rules').checked = currentConfig.Subscription.InjectRules;
            
            settingsModal.style.display = 'flex';
        } catch (e) {
            alert('Failed to load settings: ' + e.message);
        }
    }

    async function saveSettings() {
        if (!currentConfig) return;
        
        btnSaveSettings.disabled = true;
        btnSaveSettings.textContent = 'Saving...';
        
        // Update config object
        currentConfig.Core.BinName = document.getElementById('setting-core').value;
        currentConfig.Wifi.Enabled = document.getElementById('setting-wifi').checked;
        currentConfig.Schedule.Enabled = document.getElementById('setting-cron').checked;
        currentConfig.Subscription.InjectRules = document.getElementById('setting-rules').checked;
        
        try {
            const res = await fetch('/api/config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(currentConfig)
            });
            
            if (res.ok) {
                alert('Settings saved! Restarting proxy service to apply changes...');
                await fetch('/api/stop', { method: 'POST' });
                await new Promise(r => setTimeout(r, 1000));
                await fetch('/api/start', { method: 'POST' });
                
                settingsModal.style.display = 'none';
                fetchStatus();
            } else {
                const errText = await res.text();
                alert('Failed to save settings: ' + errText);
            }
        } catch (e) {
            alert('Error saving settings: ' + e.message);
        } finally {
            btnSaveSettings.disabled = false;
            btnSaveSettings.textContent = 'Save & Restart Daemon';
        }
    }

    btnSettings.addEventListener('click', openSettings);
    btnCloseSettings.addEventListener('click', () => { settingsModal.style.display = 'none'; });
    btnSaveSettings.addEventListener('click', saveSettings);
    
    // Close modal on outside click
    settingsModal.addEventListener('click', (e) => {
        if (e.target === settingsModal) {
            settingsModal.style.display = 'none';
        }
    });

    const btnStartSetup = document.getElementById('btn-start-setup');
    const btnCancelSetup = document.getElementById('btn-cancel-setup');
    const btnShowSetup = document.getElementById('btn-show-setup');
    const logsPanel = document.getElementById('setup-logs-panel');
    const setupTerminal = document.getElementById('setup-terminal');
    const setupStatusText = document.getElementById('setup-status-text');

    if (btnShowSetup) {
        btnShowSetup.addEventListener('click', () => {
            forceShowSetup = true;
            fetchStatus();
        });
    }

    if (btnCancelSetup) {
        btnCancelSetup.addEventListener('click', () => {
            forceShowSetup = false;
            fetchStatus();
        });
    }

    function startPolling() {
        const pollInterval = setInterval(async () => {
            try {
                const res = await fetch('/api/setup_log');
                const text = await res.text();
                if (text && text.trim() !== "" && text !== "Waiting for logs...") {
                    setupTerminal.innerText = text;
                    setupTerminal.scrollTop = setupTerminal.scrollHeight;
                }
                
                if (text.includes("Setup complete!")) {
                    clearInterval(pollInterval);
                    setupStatusText.innerText = "Setup complete! Restarting daemon...";
                    setupStatusText.style.color = "#10b981";
                    
                    // Restart daemon so it loads the new config and drops Setup Mode
                    await fetch('/api/restart', { method: 'POST' });
                    
                    setTimeout(() => {
                        window.location.reload();
                    }, 3000);
                } else if (text.includes("[SETUP_FAILED]")) {
                    clearInterval(pollInterval);
                    setupStatusText.innerText = "Setup failed. Check the logs above.";
                    setupStatusText.style.color = "#ef4444"; // Red color
                    btnStartSetup.disabled = false;
                    btnStartSetup.innerHTML = 'Retry Installation';
                }
            } catch (e) {
                console.error(e);
            }
        }, 1000);
    }

    if (btnStartSetup) {
        btnStartSetup.addEventListener('click', async () => {
            const core = document.getElementById('setup-core').value;
            const mirror = document.getElementById('setup-mirror').value;
            const dashboard = document.getElementById('setup-dashboard').value;

            btnStartSetup.disabled = true;
            btnStartSetup.innerHTML = 'Installing...';
            logsPanel.style.display = 'block';
            setupTerminal.innerText = "> Preparing environment...\n";

            try {
                await fetch('/api/setup', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ core: core, mirror: mirror, dashboard: dashboard })
                });

                startPolling();
            } catch (e) {
                alert('Setup failed: ' + e.message);
                btnStartSetup.disabled = false;
                btnStartSetup.innerHTML = '🚀 Start Installation';
            }
        });

        // Auto-resume checking
        const checkExistingSetup = async () => {
            try {
                const res = await fetch('/api/setup_log');
                const text = await res.text();
                // If there's a log, and it hasn't failed, and hasn't completed, and isn't just waiting
                if (text && text.trim() !== "" && text !== "Waiting for logs..." && !text.includes("[SETUP_FAILED]") && !text.includes("Setup complete!")) {
                    btnStartSetup.disabled = true;
                    btnStartSetup.innerHTML = 'Installing... (Resumed)';
                    logsPanel.style.display = 'block';
                    setupTerminal.innerText = text;
                    setupTerminal.scrollTop = setupTerminal.scrollHeight;
                    
                    // Resume polling without triggering a new setup
                    startPolling();
                }
            } catch (e) {}
        };
        setTimeout(checkExistingSetup, 500);
    }
});
