#!/system/bin/sh
# Script untuk membersihkan file persisten AWD OS saat modul di-uninstall via Magisk

AWD_DIR="/data/adb/awd"

# Nonaktifkan watchdog
mkdir -p "$AWD_DIR/tmp"
touch "$AWD_DIR/tmp/.disable_watchdog"

# Hentikan service jika sedang berjalan
killall -9 awdos 2>/dev/null

# Hapus semua file dari /data/adb/awd
rm -rf "$AWD_DIR"
