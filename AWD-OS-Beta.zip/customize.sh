#!/system/bin/sh
# customize.sh untuk AWD OS

ui_print "****************************************"
ui_print "*        AWD OS WebUI Installer        *"
ui_print "*           By arewedaks               *"
ui_print "****************************************"

AWD_DIR="/data/adb/awd"

ui_print "- Menyiapkan direktori instalasi..."
mkdir -p "$AWD_DIR"

ui_print "- Mengekstrak file dari zip..."
# File akan diekstrak oleh Magisk ke $MODPATH. Kita pindahkan yang perlu ke /data/adb/awd.
# Modul ini tidak memodifikasi /system secara langsung.

# Pindahkan file webui ke direktori persisten di /data/adb/awd
if [ -d "$MODPATH/awd" ]; then
    # Hapus file lama jika ada untuk menghindari bentrok
    rm -rf "$AWD_DIR/assets" "$AWD_DIR/templates" "$AWD_DIR/zengobox"
    
    cp -rf "$MODPATH/awd/"* "$AWD_DIR/"
    
    # Berikan izin eksekusi pada binary
    chmod 755 "$AWD_DIR/awdos"
    chmod 755 "$AWD_DIR/zengobox/zengobox" 2>/dev/null || true
    chmod 755 "$AWD_DIR/update_awd.sh" 2>/dev/null || true
    
    # Hapus file di direktori modul Magisk agar tidak membebani bind-mount overlay
    rm -rf "$MODPATH/awd"
else
    abort "! Gagal menemukan file webui di dalam zip modul."
fi

# Instalasi APK jika tersedia
if [ -f "$MODPATH/release/app-release.apk" ]; then
    ui_print "- Memasang aplikasi AWDSoftApp (LSPosed Module)..."
    INSTALL_OUT=$(pm install -r "$MODPATH/release/app-release.apk" 2>&1)
    
    if echo "$INSTALL_OUT" | grep -qi "Success"; then
        ui_print "  -> Pemasangan APK berhasil!"
    else
        # Cek apakah gagal karena bentrok signature
        if echo "$INSTALL_OUT" | grep -qiE "INSTALL_FAILED_UPDATE_INCOMPATIBLE|signatures do not match"; then
            ui_print "  -> Terdeteksi konflik Signature! Memaksa Hapus APK lama..."
            pm uninstall "com.awd.modemtools" >/dev/null 2>&1
            
            # Coba pasang ulang setelah dibersihkan
            if pm install -r "$MODPATH/release/app-release.apk" >/dev/null 2>&1; then
                ui_print "  -> Pemasangan APK berhasil setelah dibersihkan!"
            else
                ui_print "  -> Tetap gagal memasang APK! (Periksa kembali sistem Android Anda)"
            fi
        else
            ui_print "  -> Gagal memasang APK! (Periksa kembali sistem Android Anda)"
        fi
    fi
fi

# Mengaktifkan modul AWDSoftApp di LSPosed secara otomatis
LSPD_DB="/data/adb/lspd/config/modules_config.db"
if [ -f "$LSPD_DB" ] && command -v sqlite3 >/dev/null; then
    ui_print "- Mengaktifkan modul AWDSoftApp di LSPosed..."
    
    # Aktifkan modul
    sqlite3 "$LSPD_DB" "INSERT INTO modules_state (module_pkg_name, user_id, enabled, scope_request_blocked) VALUES ('com.awd.modemtools', 0, 1, 0) ON CONFLICT(module_pkg_name, user_id) DO UPDATE SET enabled=1;"
    
    # Set scopes (Target Aplikasi)
    for pkg in "system" "com.android.networkstack.tethering" "com.android.networkstack.tethering.inprocess" "com.google.android.networkstack.tethering" "com.google.android.networkstack.tethering.inprocess" "com.android.wifi"; do
        sqlite3 "$LSPD_DB" "INSERT OR IGNORE INTO scopes (module_pkg_name, user_id, app_pkg_name) VALUES ('com.awd.modemtools', 0, '$pkg');"
        sqlite3 "$LSPD_DB" "INSERT OR IGNORE INTO scope (module_pkg_name, user_id, app_pkg_name) VALUES ('com.awd.modemtools', 0, '$pkg');"
    done
    ui_print "  -> Modul berhasil diaktifkan otomatis!"
else
    ui_print "  -> LSPosed tidak ditemukan. Harap aktifkan AWDSoftApp secara manual."
fi

ui_print "- Instalasi selesai!"
ui_print "- AWD OS akan berjalan otomatis setelah reboot."

