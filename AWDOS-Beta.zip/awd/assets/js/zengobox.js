(function() {
    const statusBadge = document.getElementById('status-badge');
    const statusText = document.getElementById('status-text');
    const powerSwitch = document.getElementById('power-switch');
    const coreSelector = document.getElementById('core-selector');
    const corePid = document.getElementById('core-pid');

    const terminal = document.getElementById('terminal');
    const btnScroll = document.getElementById('btn-scroll');

    let autoScroll = true;
    let isProcessing = false;
    let currentConfig = null;
    let forceShowSetup = false;

    // Settings Modal Elements
    const btnSettings = document.getElementById('btn-settings');
    const settingsModal = document.getElementById('settings-modal');
    const btnCloseSettings = document.getElementById('btn-close-settings');
    const btnSaveSettings = document.getElementById('btn-save-settings');

    // Editor Modal Elements
    const btnShowEditor = document.getElementById('btn-show-editor');
    const editorModal = document.getElementById('editor-modal');
    const btnCloseEditor = document.getElementById('btn-close-editor');
    const btnSaveEditor = document.getElementById('btn-save-editor');
    const editorTextarea = document.getElementById('editor-textarea');
    const editorCoreName = document.getElementById('editor-core-name');

    // Toggle Auto Scroll
    btnScroll.addEventListener('click', () => {
        autoScroll = !autoScroll;
        btnScroll.classList.toggle('active', autoScroll);
        if (autoScroll) scrollToBottom();
    });

    terminal.addEventListener('scroll', () => {
        const isAtBottom = terminal.scrollHeight - terminal.scrollTop <= terminal.clientHeight + 10;
        if (!isAtBottom && autoScroll) {
            autoScroll = false;
            btnScroll.classList.remove('active');
        }
    });

    function scrollToBottom() {
        terminal.scrollTop = terminal.scrollHeight;
    }

    function formatLogLine(line) {
        if (!line) return '';
        let className = 'log-line';
        if (line.includes('[INFO]')) className += ' log-info';
        else if (line.includes('[WARN]')) className += ' log-warn';
        else if (line.includes('[ERROR]') || line.includes('[FATAL]')) className += ' log-error';

        // Extract time if exists (assuming HH:MM:SS format at start)
        const timeMatch = line.match(/^(\d{2}:\d{2}:\d{2})/);
        if (timeMatch) {
            line = line.replace(timeMatch[0], `<span class="log-time">${timeMatch[0]}</span>`);
        }
        
        return `<div class="${className}">${line}</div>`;
    }

    async function fetchLogs() {
        try {
            const res = await fetch('/api/zengobox/logs');
            const resObj = await res.json();
            
            // Assuming data is lines of text
            const lines = resObj.logs || [];
            terminal.innerHTML = lines.map(formatLogLine).join('');
            if (autoScroll) scrollToBottom();
        } catch (e) {
            console.error('Failed to fetch logs', e);
        }
    }

    async function fetchStatus() {
        try {
            const res = await fetch('/api/zengobox/status');
            const data = await res.json();
            
            if (data.needs_setup || forceShowSetup) {
                document.getElementById('setup-wizard').style.display = 'flex';
                document.getElementById('main-container').style.display = 'none';
                if (!data.needs_setup && forceShowSetup) {
                    document.getElementById('btn-cancel-setup').style.display = 'inline-block';
                } else {
                    document.getElementById('btn-cancel-setup').style.display = 'none';
                }
                return;
            } else {
                document.getElementById('setup-wizard').style.display = 'none';
                document.getElementById('main-container').style.display = 'block';
            }
            
            // Update Status Badge
            statusBadge.className = `status-badge ${data.running ? 'active' : 'offline'}`;
            statusText.textContent = data.running ? 'Active' : 'Offline';
            
            // Update Core Info
            if (data.core) {
                coreSelector.value = data.core;
            }
            corePid.textContent = data.running && data.pid > 0 ? `PID: ${data.pid}` : 'PID: ---';
            
            // Update Switch (Only if not processing a click)
            if (!isProcessing) {
                powerSwitch.checked = data.running;
                powerSwitch.disabled = false;
            }
        } catch (e) {
            statusBadge.className = 'status-badge offline';
            statusText.textContent = 'Disconnected';
            powerSwitch.disabled = true;
        }
    }

    // Handle Switch Click
    powerSwitch.addEventListener('change', async (e) => {
        isProcessing = true;
        powerSwitch.disabled = true;
        
        const action = e.target.checked ? 'start' : 'stop';
        try {
            await fetch(`/api/zengobox/${action}`, { method: 'POST' });
            // Immediate fetch to reflect status
            await fetchStatus();
            await fetchLogs();
        } catch (err) {
            window.showToast('Failed to execute command: ' + err.message, 'error');
            e.target.checked = !e.target.checked; // Revert
        } finally {
            isProcessing = false;
            powerSwitch.disabled = false;
        }
    });

    // Handle Core Selector Change
    coreSelector.addEventListener('change', async (e) => {
        const newCore = e.target.value;
        const wasRunning = powerSwitch.checked;
        
        try {
            coreSelector.disabled = true;
            // Fetch current config
            const res = await fetch('/api/zengobox/config');
            const cfg = await res.json();
            
            // Update and save
            cfg.Core.BinName = newCore;
            await fetch('/api/zengobox/config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(cfg)
            });
            
            // Restart if running
            if (wasRunning) {
                await fetch('/api/zengobox/stop', { method: 'POST' });
                await new Promise(r => setTimeout(r, 1000));
                await fetch('/api/zengobox/start', { method: 'POST' });
            }
            
            fetchStatus();
        } catch(err) {
            window.showToast('Failed to change core: ' + err.message, 'error');
        } finally {
            coreSelector.disabled = false;
        }
    });

    // Polling intervals
    fetchStatus();
    fetchLogs();
    setInterval(fetchStatus, 3000);
    setInterval(fetchLogs, 2000);

    // Settings Modal Logic
    async function openSettings() {
        try {
            const res = await fetch('/api/zengobox/config');
            currentConfig = await res.json();
            
            // Populate form
            document.getElementById('setting-core').value = currentConfig.Core.BinName || 'clash';
            document.getElementById('setting-network-mode').value = currentConfig.Network.Mode || 'tproxy';
            document.getElementById('setting-proxy-mode').value = currentConfig.Proxy.Mode || 'blacklist';
            document.getElementById('setting-ipv6').checked = currentConfig.Network.IPv6;
            document.getElementById('setting-dns').checked = currentConfig.Network.ClashDNSForward;
            document.getElementById('setting-wifi').checked = currentConfig.Wifi.Enabled;
            document.getElementById('setting-cron').checked = currentConfig.Schedule.Enabled;
            document.getElementById('setting-rules').checked = currentConfig.Subscription.InjectRules;
            
            settingsModal.classList.add('show');
        } catch (e) {
            window.showToast('Failed to load settings: ' + e.message, 'error');
        }
    }

    async function saveSettings() {
        if (!currentConfig) return;
        
        btnSaveSettings.disabled = true;
        btnSaveSettings.textContent = 'Saving...';
        
        // Update config object
        currentConfig.Core.BinName = document.getElementById('setting-core').value;
        currentConfig.Network.Mode = document.getElementById('setting-network-mode').value;
        currentConfig.Proxy.Mode = document.getElementById('setting-proxy-mode').value;
        currentConfig.Network.IPv6 = document.getElementById('setting-ipv6').checked;
        currentConfig.Network.ClashDNSForward = document.getElementById('setting-dns').checked;
        currentConfig.Wifi.Enabled = document.getElementById('setting-wifi').checked;
        currentConfig.Schedule.Enabled = document.getElementById('setting-cron').checked;
        currentConfig.Subscription.InjectRules = document.getElementById('setting-rules').checked;
        
        try {
            const res = await fetch('/api/zengobox/config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(currentConfig)
            });
            
            if (res.ok) {
                window.showToast('Settings saved! Restarting proxy service to apply changes...', 'success');
                await fetch('/api/zengobox/stop', { method: 'POST' });
                await new Promise(r => setTimeout(r, 1000));
                await fetch('/api/zengobox/start', { method: 'POST' });
                
                settingsModal.classList.remove('show');
                fetchStatus();
            } else {
                const errText = await res.text();
                window.showToast('Failed to save settings: ' + errText, 'error');
            }
        } catch (e) {
            window.showToast('Error saving settings: ' + e.message, 'error');
        } finally {
            btnSaveSettings.disabled = false;
            btnSaveSettings.textContent = 'Save & Restart Daemon';
        }
    }

    btnSettings.addEventListener('click', openSettings);
    btnCloseSettings.addEventListener('click', () => { settingsModal.classList.remove('show'); });
    btnSaveSettings.addEventListener('click', saveSettings);

    // Proxy Accounts (Box for Root Style) Logic
    const linkInput = document.getElementById('account-link-input');
    const btnSaveID = document.getElementById('btn-save-id');
    const btnSaveSG = document.getElementById('btn-save-sg');
    const listID = document.getElementById('account-list-id');
    const listSG = document.getElementById('account-list-sg');
    const proxyLoading = document.getElementById('proxy-loading-indicator');
    const btnRestartProxy = document.getElementById('btn-restart-proxy');

    async function loadAccountsList() {
        if (!listID || !listSG) return;
        
        async function fetchAndRender(target, listElement) {
            try {
                const res = await fetch('/api/zengobox/accounts?file=' + target);
                const text = await res.text();
                let accounts = [];
                
                // Extremely simple parsing
                const trimmed = text.trim();
                if (trimmed.startsWith('{') || trimmed.startsWith('[')) { // JSON (Sing-box)
                    try {
                        const parsed = JSON.parse(text);
                        const arr = Array.isArray(parsed) ? parsed : (parsed.outbounds || []);
                        accounts = arr.map(obj => obj.tag || obj.name || 'Unknown');
                    } catch(e) {}
                } else { // YAML (Clash)
                    const matches = [...text.matchAll(/-\s*name:\s*(.+)/g)];
                    accounts = matches.map(m => m[1].trim());
                }
                
                listElement.innerHTML = '';
                if (accounts.length === 0) {
                    listElement.innerHTML = '<div style="font-size: 10px; text-align: center; font-style: italic; opacity: 0.5; margin-top: 15px; color: var(--text-sub);">Kosong</div>';
                    return;
                }
                
                accounts.forEach((acc, idx) => {
                    const item = document.createElement('div');
                    item.style.cssText = 'display: flex; justify-content: space-between; align-items: center; background: rgba(0,0,0,0.1); border: 1px solid var(--border); border-radius: 8px; overflow: hidden;';
                    
                    const nameDiv = document.createElement('div');
                    nameDiv.style.cssText = 'padding: 6px 10px; font-size: 10px; font-weight: bold; flex-grow: 1; text-overflow: ellipsis; overflow: hidden; white-space: nowrap; color: var(--text-main);';
                    nameDiv.textContent = acc;
                    
                    const delBtn = document.createElement('button');
                    delBtn.style.cssText = `background: ${target === 'AKUN-ID' ? 'rgba(255,95,86,0.2)' : 'rgba(39,201,63,0.2)'}; color: ${target === 'AKUN-ID' ? '#FF5F56' : '#27C93F'}; border: none; padding: 6px 10px; cursor: pointer; display: flex; align-items: center; justify-content: center;`;
                    delBtn.innerHTML = '<span class="material-symbols-outlined" style="font-size: 14px;">delete</span>';
                    
                    delBtn.onclick = () => deleteAccount(target, idx, acc);
                    
                    item.appendChild(nameDiv);
                    item.appendChild(delBtn);
                    listElement.appendChild(item);
                });
            } catch (e) {
                listElement.innerHTML = '<div style="font-size: 10px; text-align: center; color: red;">Error loading</div>';
            }
        }
        
        await fetchAndRender('AKUN-ID', listID);
        await fetchAndRender('AKUN-SG', listSG);
    }

    async function deleteAccount(target, idx, name) {
        if (!confirm('Hapus akun: ' + name + '?')) return;
        proxyLoading.style.display = 'block';
        
        try {
            const res = await fetch('/api/zengobox/accounts?file=' + target);
            let text = await res.text();
            
            const trimmed = text.trim();
            if (trimmed.startsWith('{') || trimmed.startsWith('[')) { // JSON
                let parsed = JSON.parse(text);
                let arr = Array.isArray(parsed) ? parsed : (parsed.outbounds || []);
                arr.splice(idx, 1);
                if (!Array.isArray(parsed)) {
                    parsed.outbounds = arr;
                } else {
                    parsed = arr;
                }
                text = JSON.stringify(parsed, null, 2);
            } else { // YAML
                // Simple block deletion using regex split
                const blocks = text.split(/(?=\s*-\s*name:)/);
                text = blocks.filter(b => {
                    const match = b.match(/-\s*name:\s*(.+)/);
                    return !(match && match[1].trim() === name);
                }).join('');
            }
            
            await fetch('/api/zengobox/accounts?file=' + target, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ content: text })
            });
            
            window.showToast('Akun dihapus', 'success');
            loadAccountsList();
        } catch (e) {
            window.showToast('Gagal menghapus: ' + e.message, 'error');
        } finally {
            proxyLoading.style.display = 'none';
        }
    }

    async function processAndSave(target) {
        const link = linkInput.value.trim();
        if (!link) {
            window.showToast('Masukkan link terlebih dahulu!', 'warning');
            return;
        }
        
        proxyLoading.style.display = 'block';
        try {
            // Convert Link
            const convertRes = await fetch('/api/zengobox/accounts/convert', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ link })
            });
            
            if (!convertRes.ok) throw new Error(await convertRes.text());
            const parsedObj = await convertRes.json();
            
            // Get Current File
            const res = await fetch('/api/zengobox/accounts?file=' + target);
            let text = await res.text();
            
            if (parsedObj.yaml) { // YAML returned (Clash)
                if (!text.includes('proxies:')) {
                    text = 'proxies:\n' + text;
                }
                text = text.trim() + '\n' + parsedObj.yaml;
            } else { // JSON returned (Singbox)
                const trimmed = text.trim();
                let parsed = { outbounds: [] };
                let arr = [];
                if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
                    try { 
                        parsed = JSON.parse(text); 
                        arr = Array.isArray(parsed) ? parsed : (parsed.outbounds || []);
                    } catch(e) {}
                }
                arr.push(parsedObj);
                if (!Array.isArray(parsed)) {
                    parsed.outbounds = arr;
                } else {
                    parsed = arr;
                }
                text = JSON.stringify(parsed, null, 2);
            }
            
            // Save Back
            await fetch('/api/zengobox/accounts?file=' + target, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ content: text })
            });
            
            window.showToast('Berhasil disimpan ke ' + target, 'success');
            linkInput.value = '';
            loadAccountsList();
        } catch (e) {
            window.showToast('Gagal memproses: ' + e.message, 'error');
        } finally {
            proxyLoading.style.display = 'none';
        }
    }

    if (btnSaveID) btnSaveID.addEventListener('click', () => processAndSave('AKUN-ID'));
    if (btnSaveSG) btnSaveSG.addEventListener('click', () => processAndSave('AKUN-SG'));
    
    if (btnRestartProxy) {
        btnRestartProxy.addEventListener('click', async () => {
            btnRestartProxy.textContent = 'Restarting...';
            await fetch('/api/zengobox/stop', { method: 'POST' });
            await new Promise(r => setTimeout(r, 1000));
            await fetch('/api/zengobox/start', { method: 'POST' });
            fetchStatus();
            btnRestartProxy.textContent = 'Restart Proxy Service';
            window.showToast('Proxy di-restart!', 'success');
        });
    }

    // Initial load of account lists
    loadAccountsList();

    // Editor Logic
    let currentEditorTarget = 'config';

    window.openEditor = async function() {
        editorModal.classList.add('show');
        switchEditorTab('config');
    }

    async function switchEditorTab(target) {
        currentEditorTarget = target;
        
        // Update tab UI
        document.querySelectorAll('.editor-tab-btn').forEach(btn => {
            if (btn.dataset.target === target) {
                btn.style.background = 'var(--primary)';
                btn.style.color = 'white';
                btn.style.border = 'none';
            } else {
                btn.style.background = 'transparent';
                btn.style.color = 'var(--text-sub)';
                btn.style.border = '1px solid var(--border)';
            }
        });
        
        editorTextarea.value = 'Loading...';
        
        try {
            let url = '/api/zengobox/editor';
            if (target !== 'config') {
                url = '/api/zengobox/accounts?file=' + target;
            }
            
            const res = await fetch(url);
            if (!res.ok) throw new Error(await res.text());
            
            const content = await res.text();
            editorTextarea.value = content;
            
            // Set Core Name
            if (target === 'config') {
                const statusEl = document.getElementById('status-text');
                let c = statusEl ? statusEl.textContent.toLowerCase() : '';
                if (c.includes('clash')) editorCoreName.textContent = 'Clash';
                else if (c.includes('sing')) editorCoreName.textContent = 'Sing-Box';
                else editorCoreName.textContent = 'Config';
            } else {
                editorCoreName.textContent = target;
            }
        } catch (e) {
            window.showToast('Failed to load ' + target + ': ' + e.message, 'error');
            editorTextarea.value = '';
        }
    }

    // Tab buttons event listeners
    document.querySelectorAll('.editor-tab-btn').forEach(btn => {
        btn.addEventListener('click', () => switchEditorTab(btn.dataset.target));
    });

    async function saveEditor() {
        btnSaveEditor.disabled = true;
        btnSaveEditor.textContent = 'Saving...';
        
        try {
            const content = editorTextarea.value;
            let url = '/api/zengobox/editor';
            if (currentEditorTarget !== 'config') {
                url = '/api/zengobox/accounts?file=' + currentEditorTarget;
            }

            const res = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ content })
            });
            
            if (res.ok) {
                window.showToast(currentEditorTarget + ' saved! Restarting proxy service...', 'success');
                await fetch('/api/zengobox/stop', { method: 'POST' });
                await new Promise(r => setTimeout(r, 1000));
                await fetch('/api/zengobox/start', { method: 'POST' });
                
                editorModal.classList.remove('show');
                fetchStatus();
                if (currentEditorTarget !== 'config') {
                    loadAccountsList(); // Refresh dashboard accounts list
                }
            } else {
                window.showToast('Failed to save: ' + await res.text(), 'error');
            }
        } catch (e) {
            window.showToast('Error saving: ' + e.message, 'error');
        } finally {
            btnSaveEditor.disabled = false;
            btnSaveEditor.textContent = 'Save Config & Restart';
        }
    }

    if (btnShowEditor) btnShowEditor.addEventListener('click', window.openEditor);
    if (btnCloseEditor) btnCloseEditor.addEventListener('click', () => { editorModal.classList.remove('show'); });
    if (btnSaveEditor) btnSaveEditor.addEventListener('click', saveEditor);

    // Close modal on outside click
    settingsModal.addEventListener('click', (e) => {
        if (e.target === settingsModal) {
            settingsModal.classList.remove('show');
        }
    });

    // Wizard Logic
    const btnStartSetup = document.getElementById('btn-start-setup');
    const btnCancelSetup = document.getElementById('btn-cancel-setup');
    const btnShowSetup = document.getElementById('btn-show-setup');
    const logsPanel = document.getElementById('setup-logs-panel');
    const setupTerminal = document.getElementById('setup-terminal');
    const setupStatusText = document.getElementById('setup-status-text');

    if (btnShowSetup) {
        btnShowSetup.addEventListener('click', () => {
            forceShowSetup = true;
            fetchStatus();
        });
    }

    if (btnCancelSetup) {
        btnCancelSetup.addEventListener('click', () => {
            forceShowSetup = false;
            fetchStatus();
        });
    }

    function startPolling() {
        const pollInterval = setInterval(async () => {
            try {
                const res = await fetch('/api/zengobox/setup_log');
                const text = await res.text();
                if (text && text.trim() !== "" && text !== "Waiting for logs...") {
                    setupTerminal.innerText = text;
                    setupTerminal.scrollTop = setupTerminal.scrollHeight;
                }
                
                if (text.includes("Setup complete!")) {
                    clearInterval(pollInterval);
                    setupStatusText.innerText = "Setup complete! Restarting daemon...";
                    setupStatusText.style.color = "#10b981";
                    
                    // Restart daemon so it loads the new config and drops Setup Mode
                    await fetch('/api/zengobox/restart', { method: 'POST' });
                    
                    setTimeout(() => {
                        window.location.reload();
                    }, 3000);
                } else if (text.includes("[SETUP_FAILED]")) {
                    clearInterval(pollInterval);
                    setupStatusText.innerText = "Setup failed. Check the logs above.";
                    setupStatusText.style.color = "#ef4444"; // Red color
                    btnStartSetup.disabled = false;
                    btnStartSetup.innerHTML = 'Retry Installation';
                }
            } catch (e) {
                console.error(e);
            }
        }, 1000);
    }

    if (btnStartSetup) {
        btnStartSetup.addEventListener('click', async () => {
            const core = document.getElementById('setup-core').value;
            const mirror = document.getElementById('setup-mirror').value;
            const dashboard = document.getElementById('setup-dashboard').value;

            btnStartSetup.disabled = true;
            btnStartSetup.innerHTML = 'Installing...';
            logsPanel.style.display = 'block';
            setupTerminal.innerText = "> Preparing environment...\n";

            try {
                await fetch('/api/zengobox/setup', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ core: core, mirror: mirror, dashboard: dashboard })
                });

                startPolling();
            } catch (e) {
                window.showToast('Setup failed: ' + e.message, 'error');
                btnStartSetup.disabled = false;
                btnStartSetup.innerHTML = '🚀 Start Installation';
            }
        });

        // Auto-resume checking
        const checkExistingSetup = async () => {
            try {
                const res = await fetch('/api/zengobox/setup_log');
                const text = await res.text();
                // If there's a log, and it hasn't failed, and hasn't completed, and isn't just waiting
                if (text && text.trim() !== "" && text !== "Waiting for logs..." && !text.includes("[SETUP_FAILED]") && !text.includes("Setup complete!")) {
                    btnStartSetup.disabled = true;
                    btnStartSetup.innerHTML = 'Installing... (Resumed)';
                    logsPanel.style.display = 'block';
                    setupTerminal.innerText = text;
                    setupTerminal.scrollTop = setupTerminal.scrollHeight;
                    
                    // Resume polling without triggering a new setup
                    startPolling();
                }
            } catch (e) {}
        };
        setTimeout(checkExistingSetup, 500);
    }
})();
