#!/system/bin/sh
# customize.sh untuk AWD OS

ui_print "****************************************"
ui_print "*        AWD OS WebUI Installer        *"
ui_print "*           By arewedaks               *"
ui_print "****************************************"

AWD_DIR="/data/adb/awd"

ui_print "- Menyiapkan direktori instalasi..."
mkdir -p "$AWD_DIR"

ui_print "- Mengekstrak file dari zip..."
# File akan diekstrak oleh Magisk ke $MODPATH. Kita pindahkan yang perlu ke /data/adb/awd.
# Modul ini tidak memodifikasi /system secara langsung.

# Pindahkan file webui ke direktori persisten di /data/adb/awd
if [ -d "$MODPATH/awd" ]; then
    ui_print "- Menyalin file-file instalasi ke $AWD_DIR..."
    # Hapus folder sementara jika ada untuk hindari tumpang tindih
    rm -rf "$AWD_DIR/assets" "$AWD_DIR/templates"
    # PENTING: folder plugins/ berisi plugin EKSTERNAL yang diinstall user (via upload .awpk).
    # Jangan ikut disalin/ditimpa dari bundel modul dan jangan dihapus saat update.
    rm -rf "$MODPATH/awd/plugins"
    # Bersihkan plugin BAWAAN lama yang keliru ter-bundle pada versi sebelumnya (id: interfaces).
    # Plugin EKSTERNAL milik user (di luar daftar ini) TIDAK dihapus.
    rm -rf "$AWD_DIR/plugins/interfaces"
    cp -rf "$MODPATH/awd/"* "$AWD_DIR/"
    
    # Pastikan file binary bisa dieksekusi
    ui_print "- Mengatur permission..."
    chmod 755 "$AWD_DIR/awdos"
    # Skrip pembersih (scripts/) tetap di folder modul ($MODPATH) agar dipakai
    # oleh service.sh (watchdog). Pastikan bisa dieksekusi.
    [ -f "$MODPATH/scripts/net_cleaner.sh" ] && chmod 755 "$MODPATH/scripts/net_cleaner.sh"
    # Tombol Action (toggle on/off awdos) harus executable agar terbaca root manager
    [ -f "$MODPATH/action.sh" ] && chmod 755 "$MODPATH/action.sh"
    
    # Hapus file di direktori modul Magisk agar tidak membebani bind-mount overlay
    rm -rf "$MODPATH/awd"
else
    abort "! Gagal menemukan file webui di dalam zip modul."
fi

# Instalasi APK jika tersedia
if [ -f "$MODPATH/release/app-release.apk" ]; then
    ui_print "- Memasang aplikasi AWDSoftApp (LSPosed Module)..."
    INSTALL_OUT=$(pm install -r "$MODPATH/release/app-release.apk" 2>&1)
    
    if echo "$INSTALL_OUT" | grep -qi "Success"; then
        ui_print "  -> Pemasangan APK berhasil!"
    else
        # Cek apakah gagal karena bentrok signature
        if echo "$INSTALL_OUT" | grep -qiE "INSTALL_FAILED_UPDATE_INCOMPATIBLE|signatures do not match"; then
            ui_print "  -> Terdeteksi konflik Signature! Memaksa Hapus APK lama..."
            pm uninstall "com.awd.modemtools" >/dev/null 2>&1
            
            # Coba pasang ulang setelah dibersihkan
            if pm install -r "$MODPATH/release/app-release.apk" >/dev/null 2>&1; then
                ui_print "  -> Pemasangan APK berhasil setelah dibersihkan!"
            else
                ui_print "  -> Tetap gagal memasang APK! (Periksa kembali sistem Android Anda)"
            fi
        else
            ui_print "  -> Gagal memasang APK! (Periksa kembali sistem Android Anda)"
        fi
    fi
fi

# Mengaktifkan modul AWDSoftApp di LSPosed secara otomatis
LSPD_DB="/data/adb/lspd/config/modules_config.db"
if [ -f "$LSPD_DB" ] && command -v sqlite3 >/dev/null; then
    ui_print "- Mengaktifkan modul AWDSoftApp di LSPosed..."
    
    # Aktifkan modul
    sqlite3 "$LSPD_DB" "INSERT INTO modules_state (module_pkg_name, user_id, enabled, scope_request_blocked) VALUES ('com.awd.modemtools', 0, 1, 0) ON CONFLICT(module_pkg_name, user_id) DO UPDATE SET enabled=1;"
    
    # Set scopes (Target Aplikasi - Lengkap untuk Android 9 s/d 14+)
    for pkg in "android" "system" "com.android.networkstack.tethering" "com.android.networkstack.tethering.inprocess" "com.google.android.networkstack.tethering" "com.google.android.networkstack.tethering.inprocess" "com.android.tethering" "com.google.android.tethering" "com.android.networkstack.process" "com.google.android.networkstack.process" "com.android.wifi" "com.google.android.wifi"; do
        sqlite3 "$LSPD_DB" "INSERT OR IGNORE INTO scopes (module_pkg_name, user_id, app_pkg_name) VALUES ('com.awd.modemtools', 0, '$pkg');"
        sqlite3 "$LSPD_DB" "INSERT OR IGNORE INTO scope (module_pkg_name, user_id, app_pkg_name) VALUES ('com.awd.modemtools', 0, '$pkg');"
    done
    ui_print "  -> Modul berhasil diaktifkan otomatis!"
else
    ui_print "  -> LSPosed tidak ditemukan. Harap aktifkan AWDSoftApp secara manual."
fi

ui_print "- Instalasi selesai!"
ui_print "- AWD OS akan berjalan otomatis setelah reboot."

